   
## Screenshot

<!-- ![image](https://user-images.githubusercontent.com/78557222/124252963-2979b300-db45-11eb-8b40-bbaec97ada0b.png) -->
![image](https://user-images.githubusercontent.com/78557222/124477511-b9c42c00-ddc1-11eb-97b4-14ca92a841d9.png)



## OVERVIEW:
Instagram tool to download instagram media of any public account.
 

## FEATURES

- Get HD profile picture of any user.

- Get any public reel using sharable link.

- Get any public post from instagram.


## GET STORY

![image](https://user-images.githubusercontent.com/78557222/124477779-0a3b8980-ddc2-11eb-8c7b-38bbd72d3b67.png)

- Enter username to get story of.
- All the public stories will be listed.

## GET REEL

![image](https://user-images.githubusercontent.com/78557222/124478380-c1d09b80-ddc2-11eb-9f05-d370af6be0a3.png)

- Copy the link from reel.
- Enter it in the input area.

## GET POST 

![image](https://user-images.githubusercontent.com/78557222/124478842-3acff300-ddc3-11eb-8739-bf2e76043b60.png)

- Copy the Post Url.
- Enter ut in the input field.

## GET IGTV
![image](https://user-images.githubusercontent.com/78557222/124479150-97cba900-ddc3-11eb-92e5-eb75db57d766.png)

- Copy the IGTV URL.
- Paste it in the input field and press Search.
